#!/usr/bin/env perl
# .latexmkrc - Configuration for latexmk

# Use LuaLaTeX as the primary engine
$pdf_mode = 4;  # 4 = lualatex -> pdf
$postscript_mode = 0;
$dvi_mode = 0;

# Enable synctex for forward/backward search
$pdflatex = 'lualatex -synctex=1 -interaction=nonstopmode -file-line-error -shell-escape %O %S';
$lualatex = 'lualatex -synctex=1 -interaction=nonstopmode -file-line-error -shell-escape %O %S';

# Bibliography tools: let latexmk choose based on project
# Keep bibtex available for non-biblatex projects; biber for biblatex
$bibtex = 'bibtex %O %S';
$biber = 'biber %O %S';

# Watch mode settings
# Do not auto-start external previewer; VS Code's internal viewer will be used
$preview_mode = 0;            # 0 = do not start previewer
$preview_continuous = 1;      # Keep continuous mode enabled for -pvc

# Automatic update when changes detected
$sleep_time = 2;  # Check for changes every 2 seconds

# PDF viewer configuration for Windows
# Using SumatraPDF (recommended for auto-reload with -reuse-instance flag)
# Uncomment and adjust path if needed:
# $pdf_previewer = 'start "C:\\Program Files\\SumatraPDF\\SumatraPDF.exe" -reuse-instance %O %S';

# Alternative: Using Adobe Reader (may not support auto-reload as well)
# $pdf_previewer = 'start "C:\\Program Files (x86)\\Adobe\\Acrobat Reader DC\\Reader\\AcroRd32.exe" %O %S';

# Alternative: Using Windows default PDF viewer (disabled; VS Code will handle preview)
# $pdf_previewer = 'start "" %O %S';

# Disable explicit previewer command to avoid opening folder windows
# VS Code LaTeX Workshop will handle PDF preview internally
# Do not set $pdf_previewer to 'none', 'start ""', or any external viewer

# Settings for file clean up
@generated_exts = qw(aux bbl bcf blg fdb_latexmk fls log lof lot out run.xml toc xdv);

# Extra extensions to clean
$clean_ext = 'synctex.gz';

1;
